/*
Just draw a border round the document.body.
*/
document.body.style.border = "5px solid red";
 
console.log(getTweetIdFromDetailsPage() + " details"); 
 
function getTweetIdFromDetailsPage() {
	const links = document.getElementsByTagName('a');

	for (var i = 0; i < links.length; i++) {
		const linkHref = links[i].href;
		if (!linkHref.endsWith("/likes")) {
			continue;
		}
		
		const parts = linkHref.split('/');
		if (parts.length < 3) {
			continue;
		}
		
		if (parts[parts.length - 3] != "status") {
			continue;
		}
		console.log("D"); 
		
		const tweetId = parts[parts.length - 2];
		var isTweetId = true;
		for (var j = 0; j < tweetId.length; j++) {
			if (!isCharNumber(tweetId[j])) {
				isTweetId = false;
				break;
			}
		}
		
		if (!isTweetId) {
			continue;
		}
		
		return tweetId;
	}	
	
	return null;
}
 
function getTweetIdsFromTimeline() {
	const links = document.getElementsByTagName('a');
	const result = [];

	for (var i = 0; i < links.length; i++) {
		if (links[i].children.length == 1 && links[i].children[0].nodeName === "TIME") {
			const linkHref = links[i].href;
			if (!linkHref.startsWith("https://twitter.com/")) {
				continue;
			}
			
			const parts = linkHref.split('/');
			if (parts[parts.length - 2] != "status") {
				continue;
			}
			
			const tweetId = parts[parts.length - 1];
			var isTweetId = true;
			for (var j = 0; j < tweetId.length; j++) {
				if (!isCharNumber(tweetId[j])) {
					isTweetId = false;
					break;
				}
			}
			
			if (!isTweetId) {
				continue;
			} 
			
			result.push(tweetId);
		}
	}
	
	return result;
}

function isCharNumber(c) {
  return c >= '0' && c <= '9';
}